# W5500_SCH_PCB
+ W5500 Ethernet module (including both schematic and PCB), please use Altium Designer to open this project.
+ W5500以太网模块（包含原理图和PCB文件），请使用Altium Designer来打开工程文件。
+ PCB效果图如下 👇
![image](https://github.com/Todd-Qi/W5500_SCH_PCB/blob/main/figures/pcb1.png)
